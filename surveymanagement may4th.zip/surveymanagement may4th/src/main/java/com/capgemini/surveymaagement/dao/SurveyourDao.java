package com.capgemini.surveymaagement.dao;

import java.util.List;

import com.capgemini.surveymaagement.bean.SurveyourInfoBean;

public interface SurveyourDao {
	
	public void defaultSurveyor();
	 
	public boolean surveyourLogin();
	
	public boolean insideLogin();
	
 public List<SurveyourInfoBean> getAllSurveyours();
}
