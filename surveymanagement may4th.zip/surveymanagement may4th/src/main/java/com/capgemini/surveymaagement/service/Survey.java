package com.capgemini.surveymaagement.service;

import com.capgemini.surveymaagement.bean.SurveyourInfoBean;

public interface Survey {

	void surveyourLogin(SurveyourInfoBean surveyourInfoBean);

}
