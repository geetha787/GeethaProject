package com.capgemini.surveymaagement.exception;

public class InvalidSurveyourException extends Exception{
	 String message="username  not found";
	public InvalidSurveyourException() {
			
		}
		public InvalidSurveyourException(String message) {
			super();
			this.message = message;
		}
	@Override
		public String getMessage() {
			return message;	
		}

	}

