package com.capgemini.surveymaagement.exception;

public class InValidAdminException extends Exception {

	String message="username  not found";
	public InValidAdminException() {
			
		}
		public InValidAdminException(String message) {
			super();
			this.message = message;
		}
	@Override
		public String getMessage() {
			return message;	
		}
}
