package com.capgemini.surveymaagement.dao;

public interface RespondentDao {

	public void defaultrespondent();
	
	public boolean respondentlogin();
	
	

}

