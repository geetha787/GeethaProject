package com.capgemini.surveymaagement.bean;

public class SurveyourInfoBean {
	
private String surveyourname;

private String surveyouremail;

private String password;

public  String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}


public String getSurveyourname() {
	return surveyourname;
}

public void setSurveyourname(String surveyourname) {
	this.surveyourname = surveyourname;
}

public String getSurveyouremail() {
	return surveyouremail;
}

public void setSurveyouremail(String surveyouremail) {
	this.surveyouremail = surveyouremail;
}



}
