package com.capgemini.surveymaagement.bean;

public class RespondentInfoBean {

    private String respondentusername;
	
	private String respondentemailid;
	
	private String password;

	public String getRespondentusername() {
		return respondentusername;
	}

	public void setRespondentusername(String respondentusername) {
		this.respondentusername = respondentusername;
	}

	public String getRespondentemailid() {
		return respondentemailid;
	}

	public void setRespondentemailid(String respondentemailid) {
		this.respondentemailid = respondentemailid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	
}
