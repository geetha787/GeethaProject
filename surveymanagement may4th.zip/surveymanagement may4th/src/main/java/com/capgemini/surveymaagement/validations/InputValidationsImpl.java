package com.capgemini.surveymaagement.validations;
import java.util.regex.*;
public class InputValidationsImpl implements InputValidations{

	
	Pattern pat = null;
	Matcher mat = null;
	@Override
	public boolean nameValidation(String surveyourname) {
		pat = Pattern.compile("[A-Z]+[a-z]+");
		mat=pat.matcher(surveyourname);
		if(mat.matches()) {
			return true;
		}
		return false;
	}
	@Override
	public boolean emailidValidation(String emailId) {
		pat = Pattern.compile("^[a-zA-Z0-9_+&*-]+(?:\\."+ 
                "[a-zA-Z0-9_+&*-]+)*@" + 
                "(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
                "A-Z]{2,7}$");
		mat=pat.matcher(emailId);
		if(mat.matches()) {
			return true;
	 
	}
	return false;
	}
	@Override
	public boolean choiceValidation(String choice) {
		pat=Pattern.compile("[1-4]");
		mat=pat.matcher(choice);
		if(mat.matches()) {
			return true;
		}
	
		return false;
	}
	@Override
	public boolean surveyTitleValidation(String surveytitle) {
		pat = Pattern.compile("[A-Z]+[a-z]");
		mat = pat.matcher(surveytitle);
		if(mat.matches()) {
			return true;
		}
		return false;
	}
	@Override
	public boolean surveyDescriptionValidation(String surveydescription) {
		pat = Pattern.compile("[A-Z]+[a-z]");
		mat = pat.matcher(surveydescription);
		if(mat.matches()) {
			return true;
		}
		return false;
	}
	@Override
	public boolean questionValidation(String question) {
		pat = Pattern.compile("[A-Z]+[a-z]+[0-9]");
		mat = pat.matcher(question);
		if(mat.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean passwordValidation(String password) {
		mat = pat.matcher(password);
		if(mat.matches()) {
			return true;
		}
		return false;
	}

}
