package com.capgemini.surveymaagement.validations;

public interface InputValidations {

	public boolean nameValidation(String surveyourname);

	public boolean emailidValidation(String emailId);
	
	public boolean surveyTitleValidation(String surveytitle);
	
	public boolean surveyDescriptionValidation(String surveydescription);
	
	public boolean choiceValidation(String choice);
	
	public boolean questionValidation(String question);
	
	public boolean passwordValidation(String password);
}
