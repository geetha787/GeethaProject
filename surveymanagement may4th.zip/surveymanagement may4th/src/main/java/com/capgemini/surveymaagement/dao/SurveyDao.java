package com.capgemini.surveymaagement.dao;

import java.util.List;

import com.capgemini.surveymaagement.bean.SurveyInfoBean;

public interface SurveyDao {

	public SurveyInfoBean getSurvey(String surveytitle);
	
	public void defaultSurvey();
	 
	public boolean addSurvey(SurveyInfoBean survey);
	
	public boolean updateSurvey(SurveyInfoBean survey);

	public boolean deleteSurvey(String surveytitle);

	public List<SurveyInfoBean> getAllSurveyes();

}
