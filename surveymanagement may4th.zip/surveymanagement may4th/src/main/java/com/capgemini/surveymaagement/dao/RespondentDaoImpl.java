package com.capgemini.surveymaagement.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.surveymaagement.bean.RespondentInfoBean;
import com.capgemini.surveymaagement.bean.SurveyourInfoBean;
import com.capgemini.surveymaagement.exception.InValidRespondentException;
import com.capgemini.surveymaagement.factory.Factory;
import com.capgemini.surveymaagement.service.RespondentImpl;
import com.capgemini.surveymaagement.service.SurveyourImpl;
import com.capgemini.surveymaagement.validations.InputValidations;

public class RespondentDaoImpl implements RespondentDao{
	static final Logger logger = Logger.getLogger(RespondentDaoImpl.class);
	InputValidations inputValidations = Factory.getInputValidationsInstance();
	SurveyDao surveydao=Factory.getSurveyDaoInstance();
	RespondentImpl respondent=Factory.getRespondentInstance();
	RespondentInfoBean respondentbean=Factory.getRespondentInfoBeanInstance();
	public static List<RespondentInfoBean> respondentlist = new ArrayList<RespondentInfoBean>();
	static List<RespondentInfoBean> respondentnames = new ArrayList<RespondentInfoBean>();
	int count = 0;
	Scanner sc = new Scanner(System.in);
	@Override
	public void defaultrespondent() {
		
		
		RespondentInfoBean respondent1 = Factory.getRespondentInfoBeanInstance();
		respondent1.setRespondentusername("Geetha");
		respondent1.setRespondentemailid("geetha.tadi@gmail.com");
		respondent1.setPassword("geetha@123");
		respondentlist.add(respondent1);
		
		
		RespondentInfoBean respondent2 = Factory.getRespondentInfoBeanInstance();
		respondent2.setRespondentusername("yaswanth");
		respondent2.setRespondentemailid("yaswanth.sriram@gmail.com");
		respondent2.setPassword("yaswanth@123");
		respondentlist.add(respondent2);
		
		
		RespondentInfoBean respondent3 = Factory.getRespondentInfoBeanInstance();
		respondent3.setRespondentusername("lakshmi");
		respondent3.setRespondentemailid("lakshmi.tadi@gmail.com");
		respondent3.setPassword("lakshkmi@123");
		respondentlist.add(respondent3);
		
		
		
	}

	@Override
	public boolean respondentlogin() {
		logger.info("enter the respondent username");
		String username = sc.next();
		while (!inputValidations.nameValidation(username)) {
			logger.info("please enter valid username");
			username = sc.next();
		}
		logger.info("enter mailId ");
		String email = sc.next();
		while (!inputValidations.emailidValidation(email)) {
			logger.info("please enter valid mailId");
			email = sc.next();
		}
		
		
		logger.info("enter your password ");
		String password = sc.next();
		while (!inputValidations.passwordValidation(password)) {
			logger.info("please enter valid password");
			password = sc.next();
		}
		try {
			int count = 0;

			Iterator<RespondentInfoBean> respondent1 = respondentlist.iterator();
			while (respondent1.hasNext()) {

				RespondentInfoBean respondent = respondent1.next();
				if(respondent.getRespondentusername().equalsIgnoreCase(respondent) && respondent.getPassword().equalsIgnoreCase(password)) {
				
					count++;
				}
			}
			if (count == 0) {
				throw new InValidRespondentException();
			} else {
				logger.info("suveryour found");
				SurveyourImpl surveyor = Factory.getSurveyourInstance();
				surveyor.surveyourdetails();
			}
		} catch (InValidRespondentException e) {
			logger.error(e.getMessage());
		}
		do {
			logger.info("1.respond to new survey");
			logger.info("2.view result");
			logger.info("3.exit");
			InputValidations inputvalidation = Factory.getInputValidationsInstance();
			int option = sc.nextInt();

			while (!inputvalidation.choiceValidation(Integer.toString(option))) {
				logger.info("please enter valid choice");
				option = sc.nextInt();
				}
			switch (option) {
			case 1:
				logger.info("list of surveys");
				logger.info("enter surveytitle");
				String surveytitle = sc.nextLine();
				SurveyDao.test(surveytitle);
				break;
			case 2:
				
				
					break;
			case 3:
				
				break;

		}
		
		return false;
	}
	
	
}
