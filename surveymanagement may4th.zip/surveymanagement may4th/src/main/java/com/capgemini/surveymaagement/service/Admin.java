package com.capgemini.surveymaagement.service;

import com.capgemini.surveymaagement.bean.AdminInfoBean;

public interface Admin {

	public boolean adminLogin(AdminInfoBean adminInfoBean);

	public boolean adminService();

	public void   defaultadminLogin();
	
	
}
