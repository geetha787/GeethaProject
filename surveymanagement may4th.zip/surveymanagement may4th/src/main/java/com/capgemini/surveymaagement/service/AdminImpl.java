package com.capgemini.surveymaagement.service;

import com.capgemini.surveymaagement.bean.AdminInfoBean;

public class AdminImpl implements Admin  {

	
	public boolean adminService() {
		
		return false;
	}

	public void defaultadminLogin() {
		
	}

	

	public boolean adminLogin(AdminInfoBean adminInfoBean) {
		return false;
	}

}
