package com.capgemini.surveymaagement.service;

public class SurveyImpl implements Survey {

	
	
}
