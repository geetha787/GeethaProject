package com.capgemini.surveymaagement.factory;

import com.capgemini.surveymaagement.bean.AdminInfoBean;
import com.capgemini.surveymaagement.bean.RespondentInfoBean;
import com.capgemini.surveymaagement.bean.SurveyInfoBean;
import com.capgemini.surveymaagement.bean.SurveyourInfoBean;
import com.capgemini.surveymaagement.dao.AdminDaoImpl;
import com.capgemini.surveymaagement.dao.RespondentDaoImpl;
import com.capgemini.surveymaagement.dao.SurveyDaoImpl;
import com.capgemini.surveymaagement.dao.SurveyourDaoImpl;
import com.capgemini.surveymaagement.service.RespondentImpl;
import com.capgemini.surveymaagement.service.SurveyImpl;
import com.capgemini.surveymaagement.service.SurveyourImpl;
import com.capgemini.surveymaagement.service.AdminImpl;
import com.capgemini.surveymaagement.validations.InputValidations;
import com.capgemini.surveymaagement.validations.InputValidationsImpl;


public class Factory {
	
	private Factory(){
	
	}
	
	
	public static AdminInfoBean getAdminInfoBeanInstance() {
		AdminInfoBean admininfobean =new AdminInfoBean();
		return admininfobean;
		
	}
	
	public  static AdminDaoImpl getAdminDaoInstance() {
		AdminDaoImpl admindao =new AdminDaoImpl();
		return admindao ;
		
	}
	 
	public static AdminImpl getAdminInstance() {
		AdminImpl admin = new AdminImpl();
		return admin;
		
	}
	
	public static SurveyourInfoBean getSurveyourInfoBeanInstance() {
		SurveyourInfoBean surveyourinfobean = new SurveyourInfoBean();
		return surveyourinfobean;
		
	}
	
	public static SurveyourDaoImpl  getSurveyourDaoInstance() {
		SurveyourDaoImpl surveyourdaoimpl = new SurveyourDaoImpl();
		return surveyourdaoimpl;
		
	}
	
	public static SurveyourImpl getSurveyourInstance() {
		SurveyourImpl surveyour = new SurveyourImpl();
		return surveyour;
		
	}
	public static RespondentInfoBean getRespondentInfoBeanInstance() {
		RespondentInfoBean respondentinfobean = new RespondentInfoBean();
		return respondentinfobean;
		
	}
	public static RespondentDaoImpl getRespondentDaoInstance() {
		RespondentDaoImpl respondentdao = new RespondentDaoImpl();
		return respondentdao;
		
	}
	public static RespondentImpl getRespondentInstance() {
		RespondentImpl respondent = new RespondentImpl();
		return respondent;
		
	}
	public static SurveyInfoBean getSurveyInfoBeanInstance() {
		SurveyInfoBean surveyinfobean = new SurveyInfoBean();
		return surveyinfobean;
		
	}
	public static SurveyDaoImpl getSurveyDaoInstance() {
		SurveyDaoImpl surveydao = new SurveyDaoImpl();
		return surveydao;
	}
	public static SurveyImpl getSurveyInstance() {
		SurveyImpl survey = new SurveyImpl();
		return survey;
		
	}
	
	public static InputValidations getInputValidationsInstance() {
		InputValidations inputValidations = new InputValidationsImpl();
		return inputValidations;
	}
}