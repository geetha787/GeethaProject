package com.capgemini.surveymaagement.service;

import com.capgemini.surveymaagement.bean.SurveyourInfoBean;

public class SurveyourImpl {

		

	public void surveyourdetails() {
		
	}

	public String getSurveyourname() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getPassword() {
		// TODO Auto-generated method stub
		return null;
	}

	

	public void surveyourLogin(SurveyourInfoBean surveyourInfoBean) {
		// TODO Auto-generated method stub
		
	}

		
	}


