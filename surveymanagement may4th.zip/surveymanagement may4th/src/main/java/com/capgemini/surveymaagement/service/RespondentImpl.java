package com.capgemini.surveymaagement.service;

public class RespondentImpl {

	public void defaultrespondentLogin() {
		
	}

	public void respondentLogin() {
		
	}

}
