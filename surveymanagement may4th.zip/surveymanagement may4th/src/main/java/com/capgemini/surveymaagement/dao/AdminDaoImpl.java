package com.capgemini.surveymaagement.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.surveymaagement.bean.AdminInfoBean;
import com.capgemini.surveymaagement.bean.RespondentInfoBean;
import com.capgemini.surveymaagement.bean.SurveyInfoBean;
import com.capgemini.surveymaagement.factory.Factory;
import com.capgemini.surveymaagement.service.AdminImpl;
import com.capgemini.surveymaagement.service.Respondent;
import com.capgemini.surveymaagement.service.RespondentImpl;
import com.capgemini.surveymaagement.service.Surveyour;
import com.capgemini.surveymaagement.service.SurveyourImpl;
import com.capgemini.surveymaagement.validations.InputValidations;

public class AdminDaoImpl implements AdminDao{
	static final Logger logger = Logger.getLogger(RespondentDaoImpl.class);
	InputValidations inputValidations = Factory.getInputValidationsInstance();
	RespondentImpl respondentService = Factory.getRespondentInstance();
	SurveyourImpl surveyorService = Factory.getSurveyourInstance();
	AdminImpl adminService = Factory.getAdminInstance();
	public static List<AdminInfoBean> adminList = new ArrayList<AdminInfoBean>();
	static List<AdminInfoBean> adminNames = new ArrayList<AdminInfoBean>();
	int count = 0;
	Scanner sc = new Scanner(System.in);
	@Override
	public boolean defaultAdmin() {


		AdminInfoBean admin1 = Factory.getAdminInfoBeanInstance();
		admin1.setUsername("Geetha");
		admin1.setEmailid("geetha.tadi@gmail.com");
		admin1.setPassword("geetha@123");
		adminList.add(admin1);
		
		AdminInfoBean	admin2 = Factory.getAdminInfoBeanInstance();
		admin2.setUsername("yaswanth");
		admin2.setEmailid("yaswanth.sriram@gmail.com");
		admin2.setPassword("yaswanth@123");
		adminList.add(admin2);
		ArrayList<AdminInfoBean>list2=new ArrayList<AdminInfoBean>();
		list2.addAll(adminNames);
		
		return false;
				
	}

	@Override
	public boolean adminLogin() {
		
		
		return false;
		
	}


	@Override
	public List<AdminInfoBean> getAll() {
		
		return null;
	}

}
