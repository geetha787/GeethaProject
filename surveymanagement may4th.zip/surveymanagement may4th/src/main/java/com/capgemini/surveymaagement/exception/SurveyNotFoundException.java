package com.capgemini.surveymaagement.exception;

public class SurveyNotFoundException extends Exception {

	String message="survey  not found";
	public SurveyNotFoundException() {
			
		}
		public SurveyNotFoundException(String message) {
			super();
			this.message = message;
		}
	@Override
		public String getMessage() {
			return message;	
		}
	
	
}
