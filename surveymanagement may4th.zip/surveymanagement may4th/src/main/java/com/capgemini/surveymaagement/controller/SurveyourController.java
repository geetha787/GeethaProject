package com.capgemini.surveymaagement.controller;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.surveymaagement.bean.AdminInfoBean;
import com.capgemini.surveymaagement.bean.SurveyourInfoBean;
import com.capgemini.surveymaagement.dao.SurveyourDao;
import com.capgemini.surveymaagement.factory.Factory;
import com.capgemini.surveymaagement.service.Admin;
import com.capgemini.surveymaagement.service.AdminImpl;
import com.capgemini.surveymaagement.service.Respondent;
import com.capgemini.surveymaagement.service.RespondentImpl;
import com.capgemini.surveymaagement.service.Survey;
import com.capgemini.surveymaagement.service.Surveyour;
import com.capgemini.surveymaagement.service.SurveyourImpl;
import com.capgemini.surveymaagement.validations.InputValidations;


public class SurveyourController {

	public static void main(String[] args) {
		final Logger logger = Logger.getLogger(SurveyourController.class);
		Scanner sc = new Scanner(System.in);
		String n;
	G:	do {
			logger.info("please tell who you are");
			logger.info("1.Admin");
			logger.info("2.Surveyour ");
			logger.info("3.Respondent");
			logger.info("4.Exit");
			InputValidations inputvalidation = Factory.getInputValidationsInstance();
			int option = sc.nextInt();

			while (!inputvalidation.choiceValidation(Integer.toString(option))) {
				logger.info("please enter valid choice");
				option = sc.nextInt();

			}
			switch (option) {
			case 1:
				logger.info("Please make a login to enter your administrator Account");
				AdminImpl admin=Factory.getAdminInstance();
				admin.adminLogin(new AdminInfoBean());
				break;
			case 2:
				logger.info(" Please make a login to enter the your Surveyor account");
				SurveyourImpl surveyor = Factory.getSurveyourInstance();
			    surveyor.surveyourLogin(new SurveyourInfoBean());
					break;
			case 3:
				logger.info(" Please make a login to enter the your Respondent account");
				RespondentImpl respondent = Factory.getRespondentInstance();
			    respondent.respondentLogin();
				break;
			case 4:
				
				break G;

			}
			while(true);
		}
	}
  }


