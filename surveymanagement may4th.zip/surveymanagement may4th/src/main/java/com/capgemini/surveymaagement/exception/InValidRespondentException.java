package com.capgemini.surveymaagement.exception;

public class InValidRespondentException extends Exception {
	
	String message="username  not found";
	public InValidRespondentException() {
			
		}
		public InValidRespondentException(String message) {
			super();
			this.message = message;
		}
	@Override
		public String getMessage() {
			return message;	
		}


}
