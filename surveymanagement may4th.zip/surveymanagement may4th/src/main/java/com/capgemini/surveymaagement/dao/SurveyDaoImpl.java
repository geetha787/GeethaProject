package com.capgemini.surveymaagement.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.surveymaagement.bean.SurveyInfoBean;
import com.capgemini.surveymaagement.bean.SurveyourInfoBean;
import com.capgemini.surveymaagement.exception.SurveyNotFoundException;
import com.capgemini.surveymaagement.factory.Factory;
import com.capgemini.surveymaagement.validations.InputValidations;
import com.capgemini.surveymaagement.validations.InputValidationsImpl;

public class SurveyDaoImpl implements SurveyDao {

	static List<SurveyInfoBean> surveyes = new ArrayList<SurveyInfoBean>();

	final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger("logger");
	Scanner sc = new Scanner(System.in);
	int count=0;
	
	
	@Override
	public SurveyInfoBean getSurvey(String surveytitle) {
		for(SurveyInfoBean surveyinfobean : surveyes) {
			//try {
			if(surveyinfobean.getSurveyTitle() == surveytitle) {
				count++;
				List<SurveyInfoBean> getsurvey = new ArrayList<SurveyInfoBean>();
				getsurvey.add(surveyinfobean);
				logger.info(getsurvey);
			}
			/*
			 * else if(count==0) {
			throw new SurveyNotFoundException("Please enter a valid survey title");
			surveytitle = sc.next();
			}
			 */
			
			else {
			 
			logger.info("Enter Valid Title");  
			}
		}
		
		
	return null;
		
	}
	@Override
	public void defaultSurvey() {
		SurveyInfoBean survey1 = Factory.getSurveyInfoBeanInstance();
		survey1.setSurveyTitle("AmazonSurvey");
		survey1.setSurveyDescription("Welcome!!!");
		survey1.setSurveyDescription("Thank you for agreeing to take part in this important survey measuring customer satisfaction for Amazon.");
		survey1.setQuestion1(" How often do you shop for products online?");
		survey1.setOption1("1.Once a week\n");
		survey1.setOption2("2.Once a month\n");
		survey1.setOption3("3.Once a year\n");
		survey1.setOption4("4.Never\n");
		
	}
	@Override
	public boolean addSurvey(SurveyInfoBean survey) {
		InputValidations inputValidations = Factory.getInputValidationsInstance();
		SurveyInfoBean surveyinfobean = Factory.getSurveyInfoBeanInstance();
		logger.info("Enter SurveyTitle");
		String surveytitle = sc.next();
		while(!inputValidations.surveyTitleValidation(surveytitle)) {
			logger.info("Please enter valid survey title");
			surveytitle = sc.next();	
		}
		logger.info("Enter Survey Description");
		 String surveyDescription = sc.nextLine();
		 while(!inputValidations.surveyDescriptionValidation(surveyDescription)) {
			 logger.info("Please enter valid description ");
		 }
		 logger.info("Enter Question1 : ");
		 String question1 = sc.nextLine();
		 while(!inputValidations.questionValidation(question1)) {
			 logger.info("Enter valid question");
			 logger.info("Enter option1 :");
			String option1 = sc.nextLine();
			logger.info("Enter option2 :");
			String option2 = sc.nextLine();
			logger.info("Enter option3 :");
			String option3 = sc.nextLine();
			logger.info("Enter option4 :");
			String option4 = sc.nextLine();
		 }
		 logger.info("Enter Question2 : ");
		 String question2 = sc.nextLine();
		 while(!inputValidations.questionValidation(question2)) {
			 logger.info("Enter valid question");
			 logger.info("Enter option1 :");
				String option1 = sc.nextLine();
				logger.info("Enter option2 :");
				String option2 = sc.nextLine();
				logger.info("Enter option3 :");
				String option3 = sc.nextLine();
				logger.info("Enter option4 :");
				String option4 = sc.nextLine();
			 
		 }
		 logger.info("Enter Question3 : ");
		 String question3 = sc.nextLine();
		 while(!inputValidations.questionValidation(question3)) {
			 logger.info("Enter valid question");
			    logger.info("Enter option1 :");
			    String option1 = sc.nextLine();
				logger.info("Enter option2 :");
				String option2 = sc.nextLine();
				logger.info("Enter option3 :");
				String option3 = sc.nextLine();
				logger.info("Enter option4 :");
				String option4 = sc.nextLine();
		 }
		 logger.info("Enter Question4 : ");
		 String question4 = sc.nextLine();
		 while(!inputValidations.questionValidation(question4)) {
			   logger.info("Enter valid question");
			   logger.info("Enter option1 :");
			   String option1 = sc.nextLine();
				logger.info("Enter option2 :");
				String option2 = sc.nextLine();
				logger.info("Enter option3 :");
				String option3 = sc.nextLine();
				logger.info("Enter option4 :");
				String option4 = sc.nextLine();
		 }
		 logger.info("Enter Question5 : ");
		 String question5 = sc.nextLine();
		 while(!inputValidations.questionValidation(question5)) {
			    logger.info("Enter valid question");
			    logger.info("Enter option1 :");
			    String option1 = sc.nextLine();
				logger.info("Enter option2 :");
				String option2 = sc.nextLine();
				logger.info("Enter option3 :");
				String option3 = sc.nextLine();
				logger.info("Enter option4 :");
				String option4 = sc.nextLine();
		 }
		 logger.info("Enter Question6 : ");
		 String question6 = sc.nextLine();
		 while(!inputValidations.questionValidation(question6)) {
			 logger.info("Enter valid question");
			 logger.info("write answer");
			 String answer1 = sc.nextLine();		 
		 }
		 logger.info("Enter Question7 : ");
		 String question7 = sc.nextLine();
		 while(!inputValidations.questionValidation(question7)) {
			 logger.info("Enter valid question");
			 logger.info("write answer");
			 String answer2 = sc.nextLine();
		 }
		 logger.info("Enter Question8 : ");
		 String question8 = sc.nextLine();
		 while(!inputValidations.questionValidation(question8)) {
			 logger.info("Enter valid question");
			   logger.info("Enter option1 :");
			   String option1 = sc.nextLine();
				logger.info("Enter option2 :");
				String option2 = sc.nextLine();
				logger.info("Enter option3 :");
				String option3 = sc.nextLine();
				logger.info("Enter option4 :");
				String option4 = sc.nextLine();
		 }
		 logger.info("Enter Question9 : ");
		 String question9 = sc.nextLine();
		 while(!inputValidations.questionValidation(question9)) {
			 logger.info("Enter valid question");
			    logger.info("Enter option1 :");
			    String option1 = sc.nextLine();
				logger.info("Enter option2 :");
				String option2 = sc.nextLine();
				logger.info("Enter option3 :");
				String option3 = sc.nextLine();
				logger.info("Enter option4 :");
				String option4 = sc.nextLine();
		 }
		 logger.info("Enter Question10 : ");
		 String question10 = sc.nextLine();
		 while(!inputValidations.questionValidation(question10)) {
			 logger.info("Enter valid question");
			    logger.info("Enter option1 :");
			    String option1 = sc.nextLine();
				logger.info("Enter option2 :");
				String option2 = sc.nextLine();
				logger.info("Enter option3 :");
				String option3 = sc.nextLine();
				logger.info("Enter option4 :");
				String option4 = sc.nextLine();
		 }
		 ArrayList<SurveyInfoBean>list1 = new ArrayList<SurveyInfoBean>();
		   list1.add(surveyinfobean);
		   surveyes.addAll(list1);
		   if(list1.isEmpty()) {
			   logger.info("survey is not added \n");
			   return false;
		   }else {
			   logger.info("survey added successfully");
			   return true;
		   }
	}
	
	@Override
	public boolean updateSurvey(SurveyInfoBean survey) {
		InputValidations inputvalidations = Factory.getInputValidationsInstance();
		for (SurveyInfoBean surveyinfobean : surveyes) {
			logger.info("Enter surveytitle : ");
			String surveyTitle;
		//	try {
				surveyTitle = sc.next();
				while (!inputvalidations.surveyTitleValidation(surveyTitle)) {
					
					//throw new SurveyNotFoundException("survey not found...Enter valid surveytitle");
					logger.info("survey not found...Enter valid surveytitle");
					surveyTitle = sc.next();

				//}
				logger.info("update surveydescription : ");
				String surveyDescription;
				surveyDescription = sc.nextLine();
				while(!inputvalidations.surveyDescriptionValidation(surveyDescription)) {
					logger.info("Enter valid ");
					surveyDescription = sc.nextLine();	
				}
				surveyinfobean.setSurveyDescription(surveyDescription);
				
				logger.info("Update question 1");
				String question1 = sc.nextLine();
				while(!inputvalidations.questionValidation(question1)) {
					logger.info("Please enter valid question");
					question1 = sc.next();
				}
				surveyinfobean.setQuestion1(question1);
				
				logger.info("Update question 2");
				String question2 = sc.nextLine();
				while(!inputvalidations.questionValidation(question2)) {
					logger.info("Please enter valid question");
					question2 = sc.next();
				}
				surveyinfobean.setQuestion2(question2);
				
				logger.info("Update question 3");
				String question3 = sc.nextLine();
				while(!inputvalidations.questionValidation(question3)) {
					logger.info("Please enter valid question");
					question3 = sc.next();
				}
				surveyinfobean.setQuestion3(question3);
				
				logger.info("Update question 4");
				String question4 = sc.nextLine();
				while(!inputvalidations.questionValidation(question4)) {
					logger.info("Please enter valid question");
					question4 = sc.next();
				}
				surveyinfobean.setQuestion4(question4);
				

				logger.info("Update question 5");
				String question5 = sc.nextLine();
				while(!inputvalidations.questionValidation(question5)) {
					logger.info("Please enter valid question");
					question5 = sc.next();
				}
				surveyinfobean.setQuestion5(question5);
				
				logger.info("Update question 6");
				String question6 = sc.nextLine();
				while(!inputvalidations.questionValidation(question6)) {
					logger.info("Please enter valid question");
					question6 = sc.next();
				}
				surveyinfobean.setQuestion6(question6);
				
				logger.info("Update question 7");
				String question7 = sc.nextLine();
				while(!inputvalidations.questionValidation(question7)) {
					logger.info("Please enter valid question");
					question7 = sc.next();
				}
				surveyinfobean.setQuestion5(question7);
				
				logger.info("Update question 8");
				String question8 = sc.nextLine();
				while(!inputvalidations.questionValidation(question8)) {
					logger.info("Please enter valid question");
					question8 = sc.next();
				}
				surveyinfobean.setQuestion8(question8);
				
				logger.info("Update question 9");
				String question9 = sc.nextLine();
				while(!inputvalidations.questionValidation(question9)) {
					logger.info("Please enter valid question");
					question9 = sc.next();
				}
				surveyinfobean.setQuestion10(question9);
				
				logger.info("Update question 10");
				String question10 = sc.nextLine();
				while(!inputvalidations.questionValidation(question10)) {
					logger.info("Please enter valid question");
					question10 = sc.next();
				}
				surveyinfobean.setQuestion8(question10);
				
				logger.info("\nSurvey Updated !!");
				
				
			
		   }
    	}
		return false;
	
	}

	
	@Override
	public boolean deleteSurvey(String surveytitle) {
		Iterator<SurveyInfoBean> surveyInfoBean = surveyes.iterator();
		while (surveyInfoBean.hasNext()) {
			SurveyInfoBean itr1 = surveyInfoBean.next();
			if (itr1.getSurveyTitle() == surveytitle) {
				count++;
				surveyInfoBean.remove();
				logger.info("\nData deleted");
			}
		}
		
		return false;
	}
	


	public List<SurveyInfoBean> getAllSurveyes() {
		logger.info("Details of all Surveys !!");
		for (SurveyInfoBean surveyInfoBean : surveyes) {
			logger.info(surveyInfoBean);
		}
		return surveyes;
	}

	
}