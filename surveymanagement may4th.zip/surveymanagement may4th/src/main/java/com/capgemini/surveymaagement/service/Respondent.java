package com.capgemini.surveymaagement.service;

public interface Respondent {

	void defaultrespondentLogin();

}
