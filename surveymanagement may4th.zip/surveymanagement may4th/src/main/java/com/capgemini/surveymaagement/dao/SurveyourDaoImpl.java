package com.capgemini.surveymaagement.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.surveymaagement.bean.SurveyInfoBean;
import com.capgemini.surveymaagement.bean.SurveyourInfoBean;
import com.capgemini.surveymaagement.exception.InvalidSurveyourException;
import com.capgemini.surveymaagement.factory.Factory;
import com.capgemini.surveymaagement.service.Survey;
import com.capgemini.surveymaagement.service.Surveyour;
import com.capgemini.surveymaagement.service.SurveyourImpl;
import com.capgemini.surveymaagement.validations.InputValidations;

public class SurveyourDaoImpl implements SurveyourDao{
	static final Logger logger = Logger.getLogger(SurveyourDaoImpl.class);
	InputValidations inputValidations = Factory.getInputValidationsInstance();
	SurveyourImpl surveyour =Factory.getSurveyourInstance();
	SurveyourInfoBean surveyourbean=Factory.getSurveyourInfoBeanInstance();
	public static final List<SurveyourInfoBean> surveyourlist = new ArrayList<SurveyourInfoBean>();
	static List<SurveyourInfoBean> surveyournames = new ArrayList<SurveyourInfoBean>();
	Scanner sc = new Scanner(System.in);
	int count = 0;
	@Override
	public void defaultSurveyor() {
		SurveyourInfoBean surveyour1 = Factory.getSurveyourInfoBeanInstance();
		surveyour1.setSurveyourname("Geetha");
		surveyour1.setSurveyouremail("geetha.tadi@gmail.com");
		surveyour1.setPassword("geetha@123");
		surveyourlist.add(surveyour1);

		SurveyourInfoBean surveyour2 = Factory.getSurveyourInfoBeanInstance();
		surveyour2.setSurveyourname("yaswanth");
		surveyour2.setSurveyouremail("yaswanth.sriram@gmail.com");
		surveyour2.setPassword("yaswanth@123");
		surveyourlist.add(surveyour2);
		
		
		SurveyourInfoBean surveyour3 = Factory.getSurveyourInfoBeanInstance();
		surveyour3.setSurveyourname("lakshmi");
		surveyour3.setSurveyouremail("lakshmi.tadi@gmail.com");
		surveyour3.setPassword("lakshkmi@123");
		surveyourlist.add(surveyour3);
	}

	@Override
	public boolean surveyourLogin() {
		logger.info("enter the surveyor username");
		String username = sc.next();
		while (!inputValidations.nameValidation(username)) {
			logger.info("please enter valid username");
			username = sc.next();
		}
		logger.info("enter mailId ");
		String email = sc.next();
		while (!inputValidations.emailidValidation(email)) {
			logger.info("please enter valid mailId");
			email = sc.next();
		}
		
		
		logger.info("enter your password ");
		String password = sc.next();
		while (!inputValidations.passwordValidation(password)) {
			logger.info("please enter valid password");
			password = sc.next();
		}
		
	
	try {
		int count = 0;

		Iterator<SurveyourInfoBean> surveyour1 = surveyourlist.iterator();
		while (surveyour1.hasNext()) {
			SurveyourInfoBean itr2 = surveyour1.next();
			if (username.contentEquals(surveyourbean.getSurveyourname()) && password.contentEquals(surveyourbean.getPassword()) && email.contentEquals(surveyourbean.getSurveyouremail())) {
				count++;
			}
		}
		if (count == 0) {
			throw new InvalidSurveyourException();
		} else {
			logger.info("suveryour found");
			SurveyourImpl surveyor = Factory.getSurveyourInstance();
			surveyor.surveyourdetails();
		}
	} catch (InvalidSurveyourException e) {
		logger.error(e.getMessage());
	}
	return false;
	}
	
	
	@Override
	public boolean insideLogin() {
	
	
G:	do {
		logger.info("1.add new survey");
		logger.info("2.update survey");
		logger.info("3.delete survey");
		InputValidations inputvalidation = Factory.getInputValidationsInstance();
		int option = sc.nextInt();

		while (!inputvalidation.choiceValidation(Integer.toString(option))) {
			logger.info("please enter valid choice");
			option = sc.nextInt();
			}
		
		
		
	


	@Override
	public List<SurveyourInfoBean> getAllSurveyours() {
		logger.info("Details of all Surveyours !!");
		for (SurveyourInfoBean surveyourinfobean : surveyourlist) {
			logger.info(surveyourinfobean);
		}
		return surveyourlist;
	 }

	
    
  }


