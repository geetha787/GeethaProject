package com.capgemini.surveymaagement.dao;

import java.util.List;

import com.capgemini.surveymaagement.bean.AdminInfoBean;

public interface AdminDao {

	public boolean defaultAdmin();
	
    public boolean adminLogin();
	
	
	public List<AdminInfoBean> getAll();
}
